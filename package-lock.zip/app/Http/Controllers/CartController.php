<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Product;
use App\Models\Transaction;
use App\Models\TransactionItem;
use Illuminate\Support\Facades\DB;

class CartController extends Controller
{
    public function index(Request $request)
    {
        // Get store_id from request, default to 1
        $storeId = $request->input('store_id', 1);

        // Fetch products with their variants and inventories for the selected store
        $products = Product::with(['variants', 'inventories' => function ($query) use ($storeId) {
            $query->where('store_id', $storeId);
        }])->get();

        return view('pos.index', compact('products', 'storeId'));
    }
    public function showCart()
    {
        // Your code to show the cart
        return view('cart'); // Make sure this view exists
    }
    public function selectStorePage(Request $request)
    {
        $storeId = $request->input('store_id', 1);
        return view('cart.select', compact('storeId'));
    }

    public function clearCart(Request $request)
    {
        // Logic to clear cart
    }

    public function checkout(Request $request)
    {
        // Validate incoming request
        $request->validate([
            'cart' => 'required|array',
            'checkout_type' => 'required|string'
        ]);

        // Start a database transaction
        DB::beginTransaction();

        try {
            // Calculate the total amount
            $cart = $request->input('cart');
            $total = 0;

            // Calculate the total value of the cart items
            foreach ($cart as $item) {
                $total += $item['price'] * $item['quantity'];
            }

            // Create a new Transaction
            $transaction = Transaction::create([
                'type' => $request->input('checkout_type'),
                'total' => $total // Save the total amount
            ]);

            // Loop through cart items and create TransactionItem records
            foreach ($cart as $item) {
                TransactionItem::create([
                    'transaction_id' => $transaction->id,
                    'name' => $item['name'],
                    'variant' => $item['variant'],
                    'unit_qty' => $item['unit_qty'],
                    'price' => $item['price'],
                    'quantity' => $item['quantity']
                ]);
            }

            // Commit the transaction
            DB::commit();

            return response()->json(['success' => true]);

        } catch (\Exception $e) {
            // Rollback the transaction in case of error
            DB::rollback();
            return response()->json(['success' => false, 'message' => 'An error occurred during checkout.'], 500);
        }
    }
}