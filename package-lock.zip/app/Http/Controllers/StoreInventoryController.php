<?php

namespace App\Http\Controllers;

use App\Models\Store;
use App\Models\Product;
use App\Models\StoreInventory;
use Illuminate\Http\Request;

class StoreInventoryController extends Controller
{
    public function index()
    {
        // Use paginate to fetch a subset of records
        $inventories = StoreInventory::with('store', 'product')->paginate(10); // Adjust the number as needed
    
        return view('store_inventories.index', compact('inventories'));
    }
    // Show the form to create a new store inventory
    public function create()
    {
        $stores = Store::all(); // Retrieve all stores
        $products = Product::all(); // Retrieve all products
        return view('store_inventories.create', compact('stores', 'products'));
    }
    public function show($storeId)
    {
        $store = Store::findOrFail($storeId);
        $inventories = $store->storeInventories()->with('product')->get();
    
        return view('store_inventories.show', compact('store', 'inventories'));
    }
    // Store a new store inventory
    public function store(Request $request)
    {
        // Validate the incoming request data
        $request->validate([
            'store_id' => 'required|exists:stores,id',
            'product_id' => 'required|exists:products,id',
            'quantity' => 'required|integer|min:1',
        ]);

        // Create the store inventory
        StoreInventory::create([
            'store_id' => $request->store_id,
            'product_id' => $request->product_id,
            'quantity' => $request->quantity,
        ]);

        // Redirect to the product details page with a success message
        return redirect()->route('products.show', $request->product_id)->with('success', 'Inventory added successfully!');
    }
    public function getStock(Request $request)
{
    $storeId = $request->input('store_id');
    $productId = $request->input('product_id');

    $quantity = StoreInventory::where('store_id', $storeId)
                              ->where('product_id', $productId)
                              ->sum('quantity');

    return response()->json(['quantity' => $quantity]);
}

}
