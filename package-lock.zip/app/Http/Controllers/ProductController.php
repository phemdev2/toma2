<?php

namespace App\Http\Controllers;

use App\Models\Product;
use App\Models\ProductVariant;
use App\Models\StoreInventory;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ProductController extends Controller
{
    public function fetch()
    {
        // Fetch products from the database
        $products = Product::all(); // Adjust as needed
        return response()->json(['products' => $products]);
    }// Show the form to create a new product
    public function create()
    {
        return view('products.create');
    }

    // Store a new product and its variants
    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'barcode' => 'required|string|max:255',
            'cost' => 'required|numeric|min:0',
            // Other validation rules...
        ]);
    
        Product::create([
            'name' => $request->input('name'),
            'barcode' => $request->input('barcode'),
            'cost' => $request->input('cost'),
            'sale' => $request->input('sale'),
            // Other fields...
        ]);
    
        return redirect()->route('products.index')->with('success', 'Product created successfully.');
    }
    

    // Show a list of all products
    public function index()
    {
        $productsWithVariants = Product::with(['variants', 'storeInventories'])->paginate(10);
        return view('products.index', compact('productsWithVariants'));
    }

    // Show the form to edit an existing product
    public function edit(Product $product)
    {
        $variants = $product->variants;
        return view('products.edit', compact('product', 'variants'));
    }

    // Show the product details
    public function show(Product $product)
    {
        $product->load('variants', 'storeInventories.store');

        // Get total quantity of the product across all stores
        $totalQuantity = StoreInventory::where('product_id', $product->id)->sum('quantity');

        // Aggregate quantities by store
        $quantitiesByStore = StoreInventory::select('store_id', DB::raw('SUM(quantity) as total_quantity'))
            ->where('product_id', $product->id)
            ->groupBy('store_id')
            ->get()
            ->map(function ($item) {
                return [
                    'store' => $item->store, // Assuming Store relationship is defined in StoreInventory
                    'total_quantity' => $item->total_quantity
                ];
            });

        return view('products.show', compact('product', 'totalQuantity', 'quantitiesByStore'));
    }

    // Update an existing product and its variants
    public function update(Request $request, Product $product)
    {
        $this->validateProduct($request, $product);

        // Update the product
        $product->update($request->only('name', 'barcode', 'cost', 'sale'));

        // Manage product variants if provided
        if ($request->unit_type) {
            $this->manageProductVariants($product, $request);
        }

        return redirect()->route('products.index')->with('success', 'Product updated successfully!');
    }

    // Delete a product and its variants
    public function destroy(Product $product)
    {
        $product->variants()->delete();
        $product->storeInventories()->delete();
        $product->delete();

        return redirect()->route('products.index')->with('success', 'Product deleted successfully!');
    }

    // Show a product with the cart contents and total price
    public function showProductWithCart(Product $product)
    {
        $product->load('variants');
        $cart = session()->get('cart', []);
        $total = array_sum(array_map(fn($item) => $item['price'] * $item['quantity'], $cart));

        return view('products.show_with_cart', compact('product', 'cart', 'total'));
    }

    // Fetch all products for displaying in card view
    public function cards()
    {
        $products = Product::all();
        return view('products.cards', compact('products'));
    }

    // Validate product data
    private function validateProduct(Request $request, Product $product = null)
    {
        $request->validate([
            'name' => 'required|string|max:255',
            'barcode' => 'required|string|unique:products' . ($product ? ',barcode,' . $product->id : ''),
            'cost' => 'required|numeric',
            'sale' => 'nullable|numeric',
            'unit_type.*' => 'required|string|max:255',
            'unit_qty.*' => 'required|integer',
            'price.*' => 'required|numeric',
            'variant_id.*' => 'nullable|exists:product_variants,id',
        ]);
    }

    // Create product variants
    private function createProductVariants($productId, Request $request)
    {
        foreach ($request->unit_type as $index => $unitType) {
            ProductVariant::create([
                'product_id' => $productId,
                'unit_type' => $unitType,
                'unit_qty' => $request->unit_qty[$index],
                'price' => $request->price[$index],
            ]);
        }
    }

    // Manage product variants
    private function manageProductVariants(Product $product, Request $request)
    {
        $existingVariantIds = $request->variant_id ?? [];
        ProductVariant::where('product_id', $product->id)
            ->whereNotIn('id', $existingVariantIds)
            ->delete();

        foreach ($request->unit_type as $index => $unitType) {
            $variantData = [
                'unit_type' => $unitType,
                'unit_qty' => $request->unit_qty[$index],
                'price' => $request->price[$index],
            ];

            $variantId = $request->variant_id[$index] ?? null;

            if ($variantId) {
                // Update existing variant
                ProductVariant::where('id', $variantId)->update($variantData);
            } else {
                // Create new variant
                ProductVariant::create(array_merge(['product_id' => $product->id], $variantData));
            }
        }
    }
}