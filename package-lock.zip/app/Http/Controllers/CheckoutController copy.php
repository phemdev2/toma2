<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Transaction; // Ensure you have a Transaction model
use App\Models\TransactionItem; // Ensure you have a TransactionItem model

class CheckoutController extends Controller
{
    public function cashCheckout(Request $request)
    {
        $this->validate($request, [
            'cart_data' => 'required|json',
        ]);

        $cartData = json_decode($request->input('cart_data'), true);

        // Save transaction details
        $transaction = Transaction::create([
            'type' => 'cash',
            'total' => array_sum(array_column($cartData, 'total')), // Calculate total
        ]);

        foreach ($cartData as $item) {
            TransactionItem::create([
                'transaction_id' => $transaction->id,
                'product_name' => $item['name'],
                'variant' => $item['variant'],
                'price' => $item['price'],
                'quantity' => $item['quantity'],
                'total' => $item['total'],
            ]);
        }

        // Clear the cart
        $request->session()->forget('cart');

        // Redirect to receipt page
        return redirect()->route('receipt', ['id' => $transaction->id])
                         ->with('success', 'Order placed successfully with Cash Checkout.');
    }

    public function posCheckout(Request $request)
    {
        $this->validate($request, [
            'cart_data' => 'required|json',
        ]);

        $cartData = json_decode($request->input('cart_data'), true);

        // Save transaction details
        $transaction = Transaction::create([
            'type' => 'pos',
            'total' => array_sum(array_column($cartData, 'total')), // Calculate total
        ]);

        foreach ($cartData as $item) {
            TransactionItem::create([
                'transaction_id' => $transaction->id,
                'product_name' => $item['name'],
                'variant' => $item['variant'],
                'price' => $item['price'],
                'quantity' => $item['quantity'],
                'total' => $item['total'],
            ]);
        }

        // Clear the cart 
        $request->session()->forget('cart');

        // Redirect to receipt page
        return redirect()->route('receipt', ['id' => $transaction->id])
                         ->with('success', 'Order placed successfully with POS Checkout.');
    }
    public function showReceipt($id)
{
    $transaction = Transaction::with('items')->findOrFail($id);

    return view('receipt', compact('transaction'));
}

}
