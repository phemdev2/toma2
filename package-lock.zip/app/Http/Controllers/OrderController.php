<?php
namespace App\Http\Controllers;

use App\Models\Order;
use Illuminate\Http\Request;

class OrderController extends Controller
{
    public function show($orderId)
    {
        $order = Order::with('items.product', 'items.variant')->findOrFail($orderId);

        // Assuming your Order model has a store_id attribute
        $storeId = $order->store_id; 

        return view('receipts.show', compact('order', 'storeId'));
    }
}
