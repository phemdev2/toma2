<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Product extends Model
{
    use HasFactory;

    // Specify which attributes should be mass assignable
    protected $fillable = ['name', 'barcode', 'cost','sale', 'allow_overselling'];

    // Define the relationship with ProductVariant
    public function variants()
    {
        return $this->hasMany(ProductVariant::class);
    }
    public function storeInventories()
    {
        return $this->hasMany(StoreInventory::class);
    }
     // Method to get inventory quantity for a specific store
     public function getStoreQuantity($storeId)
     {
         return $this->storeInventories()->where('store_id', $storeId)->sum('quantity');
     }
    public function inventories()
    {
        return $this->hasMany(StoreInventory::class, 'product_id', 'id');
    }
}