<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class Order extends Model
{
    protected $fillable = [
        'payment_method',
        'order_date',
    ];
    public function items()
    {
        return $this->hasMany(OrderItem::class);
    }
    // Define any relationships or additional methods here
}
