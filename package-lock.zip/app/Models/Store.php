<?php
namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Store extends Model
{
    use HasFactory;

    // Specify the fillable attributes for mass assignment
    protected $fillable = [
        'name',
    ];

    /**
     * Define a one-to-many relationship with StoreInventory.
     */
    public function storeInventories()
    {
        return $this->hasMany(StoreInventory::class);
    }

    /**
     * Define a many-to-many relationship with SalesRep.
     */
    public function salesReps()
    {
        return $this->belongsToMany(SalesRep::class, 'store_sales_rep');
    }
}
