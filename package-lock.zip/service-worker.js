const CACHE_NAME = 'app-cache-v1';
const STATIC_ASSETS = [
    '/',
    '/styles/main.css',
    '/scripts/main.js',
    '/image.png',
    // Add other static assets you want to cache
];
const API_URL = '/api/products';

// Install event: Cache static assets
self.addEventListener('install', event => {
    event.waitUntil(
        caches.open(CACHE_NAME)
            .then(cache => {
                console.log('Caching static assets');
                return cache.addAll(STATIC_ASSETS);
            })
    );
});

// Fetch event: Serve from cache or fetch from network
self.addEventListener('fetch', event => {
    if (event.request.url.includes(API_URL)) {
        event.respondWith(
            caches.open(CACHE_NAME).then(cache => {
                return fetch(event.request)
                    .then(response => {
                        // Cache the new response and return it
                        cache.put(event.request, response.clone());
                        return response;
                    })
                    .catch(() => {
                        // Return cached response if fetch fails
                        return cache.match(event.request);
                    });
            })
        );
    } else {
        event.respondWith(
            caches.match(event.request)
                .then(response => {
                    return response || fetch(event.request);
                })
        );
    }
});

// Activate event: Clean up old caches
self.addEventListener('activate', event => {
    const cacheWhitelist = [CACHE_NAME];
    event.waitUntil(
        caches.keys().then(cacheNames => {
            return Promise.all(
                cacheNames.map(cacheName => {
                    if (!cacheWhitelist.includes(cacheName)) {
                        return caches.delete(cacheName);
                    }
                })
            );
        })
    );
});

// Background Sync
self.addEventListener('sync', event => {
    if (event.tag === 'sync-checkout') {
        event.waitUntil(syncCheckoutData());
    }
});

function syncCheckoutData() {
    return caches.open(CACHE_NAME).then(cache => {
        return cache.match('/savedCheckout')
            .then(response => response.json())
            .then(checkoutData => {
                if (checkoutData) {
                    return fetch('/api/checkout', {
                        method: 'POST',
                        body: JSON.stringify(checkoutData),
                        headers: {
                            'Content-Type': 'application/json'
                        }
                    })
                    .then(response => response.json())
                    .then(data => {
                        if (data.order_id) {
                            console.log('Checkout data synced successfully', data);
                            return cache.delete('/savedCheckout');
                        }
                    });
                }
            });
    });
}
