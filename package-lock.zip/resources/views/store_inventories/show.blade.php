@extends('layouts.app')

@section('title', 'Store Inventory Details')

@section('content')
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-4">{{ $store->name }} - Inventory Details</h1>

        <a href="{{ route('store_inventories.index') }}" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 mb-4 inline-block">Back to Inventory List</a>

        <!-- Inventories Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-md">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($inventories as $inventory)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $inventory->product->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $inventory->quantity }}</td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    </div>
@endsection
