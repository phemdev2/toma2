@extends('layouts.app')

@section('title', 'Store Inventories')

@section('content')
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-4">Store Inventories</h1>

        <!-- Filter and View Options -->
        <div class="mb-4">
            <a href="{{ route('store_inventories.create') }}" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Add New Inventory</a>
        </div>

        <!-- Inventories Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-md">
                <thead>
                    <tr class="bg-gray-100 border-b border-gray-200">
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Store</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($inventories as $inventory)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $inventory->store->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $inventory->product->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap">{{ $inventory->quantity }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="{{ route('store_inventories.show', $inventory->store_id) }}" class="text-blue-500 hover:text-blue-600">View</a>
                                <form action="{{ route('store_inventories.destroy', $inventory->id) }}" method="POST" class="inline">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-500 hover:text-red-600 ml-2" onclick="return confirm('Are you sure you want to delete this inventory?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            {{ $inventories->links() }}
        </div>
    </div>
@endsection
