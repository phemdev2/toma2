@extends('layouts.app')

@section('title', 'Select Store')

@section('content')
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-6">Select a Store</h1>
        <form method="GET" action="{{ route('cart.index') }}" class="space-y-4">
            <input type="hidden" name="store_id" id="store_id" value="">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                @foreach($stores as $store)
                    <div class="bg-white border border-gray-200 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer" onclick="selectStore({{ $store->id }})">
                        <div class="p-4">
                            <h5 class="text-xl font-semibold mb-2">{{ $store->name }}</h5>
                            <p class="text-gray-600">{{ $store->description }}</p>
                        </div>
                    </div>
                @endforeach
            </div>
        </form>
    </div>

    <script>
        function selectStore(storeId) {
            document.getElementById('store_id').value = storeId;
            document.forms[0].submit();
        }
    </script>
@endsection
