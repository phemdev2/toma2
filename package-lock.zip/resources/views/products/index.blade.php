@extends('layouts.app')

@section('title', 'Product List')

@section('content')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Product List</h1>

    <!-- Button to Create a New Product -->
    <div class="mb-6">
        <a href="{{ route('products.create') }}" class="inline-block bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">
            Create New Product
        </a>
    </div>

    @if($productsWithVariants->isEmpty())
        <div class="bg-white shadow rounded-lg p-4">
            <p class="text-gray-600">No products available.</p>
        </div>
    @else
        <div class="bg-white shadow rounded-lg p-4">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Barcode</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cost</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sale</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variants</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inventory by Store</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    @foreach($productsWithVariants as $product)
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">{{ $product->name }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">{{ $product->barcode }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${{ number_format($product->cost, 2) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">${{ number_format($product->sale, 2) }}</td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <ul class="list-disc list-inside">
                                    @foreach($product->variants as $variant)
                                        <li>{{ $variant->unit_type }} - {{ $variant->unit_qty }} units - ${{ number_format($variant->price, 2) }}</li>
                                    @endforeach
                                </ul>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                @php
                                    // Initialize totals
                                    $storeTotals = [];
                                    
                                    // Sum quantities by store
                                    foreach ($product->storeInventories as $inventoryItem) {
                                        if ($inventoryItem->store) { // Ensure store is not null
                                            $storeName = $inventoryItem->store->name;
                                            $storeId = $inventoryItem->store->id; // Get the store ID
                                            $storeTotals[$storeName] = [
                                                'total' => ($storeTotals[$storeName]['total'] ?? 0) + $inventoryItem->quantity,
                                                'id' => $storeId // Store ID for the link
                                            ];
                                        }
                                    }
                                @endphp
                                <ul class="list-disc list-inside">
                                    @forelse($storeTotals as $storeName => $data)
                                        <li>
                                            <a href="{{ route('store.show', $data['id']) }}" class="text-blue-500 hover:text-blue-600">
                                                {{ $storeName }}: {{ $data['total'] }}
                                            </a>
                                        </li>
                                    @empty
                                        <li>No inventory available.</li>
                                    @endforelse
                                </ul>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="{{ route('products.edit', $product->id) }}" class="text-blue-500 hover:text-blue-600">Edit</a>
                                <form action="{{ route('products.destroy', $product->id) }}" method="POST" class="inline-block">
                                    @csrf
                                    @method('DELETE')
                                    <button type="submit" class="text-red-500 hover:text-red-600" onclick="return confirm('Are you sure you want to delete this product?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
        </div>
    @endif
</div>
@endsection
