@extends('layouts.app')

@section('title', 'Product Registration')

@section('content')
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-6">Product Registration</h1>

    @if(session('success'))
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6" role="alert">
            {{ session('success') }}
        </div>
    @endif

    <form action="{{ route('products.store') }}" method="POST">
        @csrf

        <!-- Tabs Navigation -->
        <div class="relative">
            <ul class="flex border-b border-gray-300 mb-4">
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-blue-500 border-b-2 border-blue-500 cursor-pointer" id="general-tab" data-target="#general" role="tab">General Info</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-500 cursor-pointer" id="variants-tab" data-target="#variants" role="tab">Variants</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-500 cursor-pointer" id="pricing-tab" data-target="#pricing" role="tab">Pricing</a>
                </li>
            </ul>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
            <!-- General Info Tab -->
            <div class="tab-pane active" id="general">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Product Name</label>
                    <input type="text" name="name" id="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" value="{{ old('name') }}" required>
                    @error('name')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="barcode" class="block text-sm font-medium text-gray-700">Barcode</label>
                    <input type="text" name="barcode" id="barcode" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" value="{{ old('barcode') }}" required>
                    @error('barcode')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="description" id="description" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50">{{ old('description') }}</textarea>
                    @error('description')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>

            <!-- Variants Tab -->
            <div class="tab-pane hidden" id="variants">
                <div id="variants-container" class="mt-4">
                    <div class="variant mb-4">
                        <div class="mb-4">
                            <label for="unit_type_0" class="block text-sm font-medium text-gray-700">Unit Type</label>
                            <input type="text" name="unit_type[]" id="unit_type_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                        </div>
                        <div class="mb-4">
                            <label for="unit_qty_0" class="block text-sm font-medium text-gray-700">Unit Quantity</label>
                            <input type="number" name="unit_qty[]" id="unit_qty_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                        </div>
                        <div class="mb-4">
                            <label for="price_0" class="block text-sm font-medium text-gray-700">Price</label>
                            <input type="number" name="price[]" id="price_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" required>
                        </div>
                    </div>
                </div>

                <button type="button" id="add-variant" class="bg-gray-200 text-gray-700 py-2 px-4 rounded hover:bg-gray-300">Add Another Variant</button>
            </div>

            <!-- Pricing Tab -->
            <div class="tab-pane hidden" id="pricing">
                <div class="mb-4">
                    <label for="cost" class="block text-sm font-medium text-gray-700">Cost</label>
                    <input type="number" name="cost" id="cost" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" value="{{ old('cost') }}" required>
                    @error('cost')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>

                <div class="mb-4">
                    <label for="sale" class="block text-sm font-medium text-gray-700">Sale Price (Optional)</label>
                    <input type="number" name="sale" id="sale" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" value="{{ old('sale') }}">
                    @error('sale')
                        <p class="mt-2 text-sm text-red-600">{{ $message }}</p>
                    @enderror
                </div>
            </div>
        </div>

        <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 mt-6">Create Product</button>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('[data-target]');
            const tabPanes = document.querySelectorAll('.tab-pane');

            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const target = document.querySelector(this.getAttribute('data-target'));

                    // Remove active class from all tabs and hide all tab panes
                    tabs.forEach(t => t.classList.remove('text-blue-500', 'border-blue-500'));
                    tabPanes.forEach(pane => pane.classList.add('hidden'));

                    // Add active class to the clicked tab and show the target tab pane
                    this.classList.add('text-blue-500', 'border-blue-500');
                    target.classList.remove('hidden');
                });
            });

            // Set the initial active tab
            document.querySelector('#general-tab').click();
        });

        document.getElementById('add-variant').addEventListener('click', function() {
            const container = document.getElementById('variants-container');
            const index = container.children.length; // Get current count of variants

            const newVariant = `
                <div class="variant mb-4">
                    <div class="mb-4">
                        <label for="unit_type_${index}" class="block text-sm font-medium text-gray-700">Unit Type</label>
                        <input type="text" name="unit_type[]" id="unit_type_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                    </div>
                    <div class="mb-4">
                        <label for="unit_qty_${index}" class="block text-sm font-medium text-gray-700">Unit Quantity</label>
                        <input type="number" name="unit_qty[]" id="unit_qty_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                    </div>
                    <div class="mb-4">
                        <label for="price_${index}" class="block text-sm font-medium text-gray-700">Price</label>
                        <input type="number" name="price[]" id="price_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" required>
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', newVariant);
        });
    </script>
</div>
@endsection
