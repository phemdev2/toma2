@extends('layouts.app')

@section('title', 'Edit Product')

@section('content')
    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-6">Edit Product</h1>

        @if(session('success'))
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                {{ session('success') }}
            </div>
        @endif

        <form action="{{ route('products.update', $product->id) }}" method="POST">
            @csrf
            @method('PUT')

            <!-- Tabs Navigation -->
            <ul class="flex border-b mb-4">
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-blue-600 border-b-2 border-blue-600 cursor-pointer" id="general-tab" data-toggle="tab" href="#general">General Info</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-600 cursor-pointer" id="pricing-tab" data-toggle="tab" href="#pricing">Pricing</a>
                </li>
                <li>
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-600 cursor-pointer" id="variants-tab" data-toggle="tab" href="#variants">Variants</a>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content">
                <!-- General Info Tab -->
                <div id="general" class="tab-pane hidden">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700">Product Name</label>
                        <input type="text" name="name" id="name" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('name', $product->name) }}" required>
                        @error('name')
                            <div class="text-red-500 mt-1 text-sm">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="barcode" class="block text-gray-700">Barcode</label>
                        <input type="text" name="barcode" id="barcode" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('barcode', $product->barcode) }}" required>
                        @error('barcode')
                            <div class="text-red-500 mt-1 text-sm">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="description" class="block text-gray-700">Description</label>
                        <textarea name="description" id="description" class="form-textarea mt-1 block w-full border-gray-300 rounded-md shadow-sm">{{ old('description', $product->description) }}</textarea>
                        @error('description')
                            <div class="text-red-500 mt-1 text-sm">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <!-- Pricing Tab -->
                <div id="pricing" class="tab-pane hidden">
                    <div class="mb-4">
                        <label for="cost" class="block text-gray-700">Cost</label>
                        <input type="number" name="cost" id="cost" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('cost', $product->cost) }}" step="0.01" required>
                        @error('cost')
                            <div class="text-red-500 mt-1 text-sm">{{ $message }}</div>
                        @enderror
                    </div>

                    <div class="mb-4">
                        <label for="sale" class="block text-gray-700">Sale Price (Optional)</label>
                        <input type="number" name="sale" id="sale" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('sale', $product->sale) }}" step="0.01">
                        @error('sale')
                            <div class="text-red-500 mt-1 text-sm">{{ $message }}</div>
                        @enderror
                    </div>
                </div>

                <!-- Variants Tab -->
                <div id="variants" class="tab-pane hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-300" id="variants-table">
                            <thead>
                                <tr class="border-b">
                                    <th class="px-4 py-2 text-left">Unit Type</th>
                                    <th class="px-4 py-2 text-left">Unit Quantity</th>
                                    <th class="px-4 py-2 text-left">Price</th>
                                    <th class="px-4 py-2 text-left">Action</th>
                                </tr>
                            </thead>
                            <tbody id="variants-container">
                                @foreach($product->variants as $index => $variant)
                                    <tr id="variant_{{ $index }}" class="border-b">
                                        <td class="px-4 py-2">
                                            <input type="text" name="unit_type[]" id="unit_type_{{ $index }}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('unit_type.' . $index, $variant->unit_type) }}" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <input type="number" name="unit_qty[]" id="unit_qty_{{ $index }}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('unit_qty.' . $index, $variant->unit_qty) }}" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <input type="number" name="price[]" id="price_{{ $index }}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="{{ old('price.' . $index, $variant->price) }}" step="0.01" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 delete-variant" data-index="{{ $index }}">Delete</button>
                                        </td>
                                    </tr>
                                @endforeach
                            </tbody>
                        </table>
                        <button type="button" id="add-variant" class="mt-3 px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">Add Another Variant</button>
                    </div>
                </div>
            </div>

            <button type="submit" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Update Product</button>
        </form>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabs = document.querySelectorAll('[data-toggle="tab"]');
                const tabPanes = document.querySelectorAll('.tab-pane');

                tabs.forEach(tab => {
                    tab.addEventListener('click', function() {
                        // Remove active class from all tabs and hide all tab panes
                        tabs.forEach(t => t.classList.remove('text-blue-600', 'border-blue-600'));
                        tabPanes.forEach(pane => pane.classList.add('hidden'));

                        // Add active class to the clicked tab and show the corresponding tab pane
                        tab.classList.add('text-blue-600', 'border-blue-600');
                        const targetPane = document.querySelector(tab.getAttribute('href'));
                        targetPane.classList.remove('hidden');
                    });
                });

                // Set the default tab to active
                document.getElementById('general-tab').click();
            });

            document.getElementById('add-variant').addEventListener('click', function() {
                const container = document.getElementById('variants-container');
                const index = container.children.length;

                const newVariantRow = `
                    <tr id="variant_${index}" class="border-b">
                        <td class="px-4 py-2">
                            <input type="text" name="unit_type[]" id="unit_type_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        </td>
                        <td class="px-4 py-2">
                            <input type="number" name="unit_qty[]" id="unit_qty_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        </td>
                        <td class="px-4 py-2">
                            <input type="number" name="price[]" id="price_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" step="0.01" required>
                        </td>
                        <td class="px-4 py-2">
                            <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 delete-variant" data-index="${index}">Delete</button>
                        </td>
                    </tr>
                `;

                container.insertAdjacentHTML('beforeend', newVariantRow);
            });

            document.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('delete-variant')) {
                    const index = e.target.getAttribute('data-index');
                    const variantElement = document.getElementById(`variant_${index}`);
                    if (variantElement) {
                        variantElement.remove();
                    }
                }
            });
        </script>
    </div>
@endsection
