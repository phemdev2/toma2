@extends('layouts.app')

@section('title', $product->name)

@section('content')
<div class="container">
    <h1>{{ $product->name }}</h1>
    <p>Barcode: {{ $product->barcode }}</p>
    <p>Cost: ${{ number_format($product->cost, 2) }}</p>
    <p>Sale: ${{ number_format($product->sale ?? 0, 2) }}</p>

    <h3>Variants</h3>
    <ul class="list-unstyled">
        @if($product->variants->isNotEmpty())
            @foreach($product->variants as $variant)
                <li>
                    {{ $variant->unit_type }} - 
                    {{ $variant->unit_qty }} units - 
                    ${{ number_format($variant->price, 2) }}
                </li>
            @endforeach
        @else
            <li>No variants available.</li>
        @endif
    </ul>

    <h3>Store Inventory</h3>
    <table class="table table-striped">
        <thead>
            <tr>
                <th>Store</th>
                <th>Total Quantity</th>
            </tr>
        </thead>
        <tbody>
            @forelse($quantitiesByStore as $quantityByStore)
                <tr>
                    <td>{{ $quantityByStore->store->name ?? 'Unknown Store' }}</td>
                   

                    
                </tr>
            @empty
                <tr>
                    <td colspan="2">No inventory data available.</td>
                </tr>
            @endforelse
        </tbody>
    </table>

    <h4>Total Quantity Across All Stores</h4>
    <p>{{ number_format($totalQuantity, 2) }} units</p>
</div>
@endsection