<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>@yield('title', 'Product Inventory')</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="{{ asset('css/app.css') }}">
    
    <style>
        /* Add custom styles here if needed */
    </style>
</head>
<body>
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <a class="navbar-brand" href="{{ route('products.index') }}">Inventory App</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarNav">
            <ul class="navbar-nav mr-auto">
                <li class="nav-item {{ request()->is('products') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('products.index') }}">Products</a>
                </li>
                <li class="nav-item {{ request()->is('store_inventories/create') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('store_inventories.create') }}">Add Inventory</a>
                </li>
                <li class="nav-item {{ request()->is('products/create') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('products.create') }}">Create Product</a>
                </li>
                <li class="nav-item {{ request()->is('products/cards') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('products.cards') }}">Product Cards</a>
                </li>
                <li class="nav-item {{ request()->is('transactions') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('transactions.index') }}">Transactions</a>
                </li>
                <li class="nav-item {{ request()->is('store_inventories') ? 'active' : '' }}">
                    <a class="nav-link" href="{{ route('store_inventories.index') }}">Store Inventories</a>
                </li>
                <li class="nav-item {{ request()->is('inventory/top-up') ? 'active' : '' }}">
    <a class="nav-link" href="{{ route('inventory.top-up') }}">Update Inventories</a>
</li>
                <!-- Add more navigation items here if needed -->
            </ul>
        </div>
    </nav>

    <div class="container mt-4">
        @if(session('success'))
            <div class="alert alert-success">
                {{ session('success') }}
            </div>
        @endif
        @yield('content')
    </div>

    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.0.7/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>