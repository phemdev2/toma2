

<?php $__env->startSection('title', 'Select Store'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-6">Select a Store</h1>
        <form method="GET" action="<?php echo e(route('cart.index')); ?>" class="space-y-4">
            <input type="hidden" name="store_id" id="store_id" value="">
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                <?php $__currentLoopData = $stores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $store): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="bg-white border border-gray-200 rounded-lg shadow-md hover:shadow-lg transition-shadow duration-300 cursor-pointer" onclick="selectStore(<?php echo e($store->id); ?>)">
                        <div class="p-4">
                            <h5 class="text-xl font-semibold mb-2"><?php echo e($store->name); ?></h5>
                            <p class="text-gray-600"><?php echo e($store->description); ?></p>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </form>
    </div>

    <script>
        function selectStore(storeId) {
            document.getElementById('store_id').value = storeId;
            document.forms[0].submit();
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/stores/index.blade.php ENDPATH**/ ?>