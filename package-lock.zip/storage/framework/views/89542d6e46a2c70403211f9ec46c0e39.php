

<?php $__env->startSection('title', 'Product List'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Product List</h1>

    <!-- Button to Create a New Product -->
    <div class="mb-6">
        <a href="<?php echo e(route('products.create')); ?>" class="inline-block bg-green-500 text-white py-2 px-4 rounded hover:bg-green-600">
            Create New Product
        </a>
    </div>

    <?php if($productsWithVariants->isEmpty()): ?>
        <div class="bg-white shadow rounded-lg p-4">
            <p class="text-gray-600">No products available.</p>
        </div>
    <?php else: ?>
        <div class="bg-white shadow rounded-lg p-4">
            <table class="min-w-full divide-y divide-gray-200">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Name</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Barcode</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Cost</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Sale</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Variants</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Inventory by Store</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $productsWithVariants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900"><?php echo e($product->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($product->barcode); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?php echo e(number_format($product->cost, 2)); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">$<?php echo e(number_format($product->sale, 2)); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <ul class="list-disc list-inside">
                                    <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <li><?php echo e($variant->unit_type); ?> - <?php echo e($variant->unit_qty); ?> units - $<?php echo e(number_format($variant->price, 2)); ?></li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </ul>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                                <?php
                                    // Initialize totals
                                    $storeTotals = [];
                                    
                                    // Sum quantities by store
                                    foreach ($product->storeInventories as $inventoryItem) {
                                        if ($inventoryItem->store) { // Ensure store is not null
                                            $storeName = $inventoryItem->store->name;
                                            $storeId = $inventoryItem->store->id; // Get the store ID
                                            $storeTotals[$storeName] = [
                                                'total' => ($storeTotals[$storeName]['total'] ?? 0) + $inventoryItem->quantity,
                                                'id' => $storeId // Store ID for the link
                                            ];
                                        }
                                    }
                                ?>
                                <ul class="list-disc list-inside">
                                    <?php $__empty_1 = true; $__currentLoopData = $storeTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $storeName => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                        <li>
                                            <a href="<?php echo e(route('store.show', $data['id'])); ?>" class="text-blue-500 hover:text-blue-600">
                                                <?php echo e($storeName); ?>: <?php echo e($data['total']); ?>

                                            </a>
                                        </li>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                        <li>No inventory available.</li>
                                    <?php endif; ?>
                                </ul>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="<?php echo e(route('products.edit', $product->id)); ?>" class="text-blue-500 hover:text-blue-600">Edit</a>
                                <form action="<?php echo e(route('products.destroy', $product->id)); ?>" method="POST" class="inline-block">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-600" onclick="return confirm('Are you sure you want to delete this product?');">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/products/index.blade.php ENDPATH**/ ?>