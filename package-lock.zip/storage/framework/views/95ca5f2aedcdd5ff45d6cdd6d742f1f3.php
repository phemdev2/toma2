<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-4">Dashboard</h1>
    
    <!-- Example Card Component -->
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <div class="bg-white shadow rounded-lg p-4">
            <h2 class="text-xl font-semibold mb-2">Card Title 1</h2>
            <p class="text-gray-600">Content for card 1.</p>
        </div>
        <div class="bg-white shadow rounded-lg p-4">
            <h2 class="text-xl font-semibold mb-2">Card Title 2</h2>
            <p class="text-gray-600">Content for card 2.</p>
        </div>
        <div class="bg-white shadow rounded-lg p-4">
            <h2 class="text-xl font-semibold mb-2">Card Title 3</h2>
            <p class="text-gray-600">Content for card 3.</p>
        </div>
    </div>

    <!-- Example Chart Component -->
    <div class="bg-white shadow rounded-lg p-4 mt-6">
        <h2 class="text-xl font-semibold mb-2">Chart Title</h2>
        <div id="chart" style="height: 300px;"></div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
<script>
    // Example JavaScript to initialize a chart
    document.addEventListener('DOMContentLoaded', function () {
        var ctx = document.getElementById('chart').getContext('2d');
        var myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: ['Red', 'Blue', 'Yellow', 'Green', 'Purple', 'Orange'],
                datasets: [{
                    label: '# of Votes',
                    data: [12, 19, 3, 5, 2, 3],
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/dashboard.blade.php ENDPATH**/ ?>