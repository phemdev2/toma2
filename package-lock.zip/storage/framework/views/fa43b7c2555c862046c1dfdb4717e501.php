

<?php $__env->startSection('title', 'Product Registration'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mx-auto px-4 py-6">
    <h1 class="text-2xl font-semibold mb-6">Product Registration</h1>

    <?php if(session('success')): ?>
        <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-6" role="alert">
            <?php echo e(session('success')); ?>

        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('products.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <!-- Tabs Navigation -->
        <div class="relative">
            <ul class="flex border-b border-gray-300 mb-4">
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-blue-500 border-b-2 border-blue-500 cursor-pointer" id="general-tab" data-target="#general" role="tab">General Info</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-500 cursor-pointer" id="variants-tab" data-target="#variants" role="tab">Variants</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-500 cursor-pointer" id="pricing-tab" data-target="#pricing" role="tab">Pricing</a>
                </li>
            </ul>
        </div>

        <!-- Tab Content -->
        <div class="tab-content">
            <!-- General Info Tab -->
            <div class="tab-pane active" id="general">
                <div class="mb-4">
                    <label for="name" class="block text-sm font-medium text-gray-700">Product Name</label>
                    <input type="text" name="name" id="name" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" value="<?php echo e(old('name')); ?>" required>
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="barcode" class="block text-sm font-medium text-gray-700">Barcode</label>
                    <input type="text" name="barcode" id="barcode" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" value="<?php echo e(old('barcode')); ?>" required>
                    <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="description" class="block text-sm font-medium text-gray-700">Description</label>
                    <textarea name="description" id="description" rows="4" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50"><?php echo e(old('description')); ?></textarea>
                    <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>

            <!-- Variants Tab -->
            <div class="tab-pane hidden" id="variants">
                <div id="variants-container" class="mt-4">
                    <div class="variant mb-4">
                        <div class="mb-4">
                            <label for="unit_type_0" class="block text-sm font-medium text-gray-700">Unit Type</label>
                            <input type="text" name="unit_type[]" id="unit_type_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                        </div>
                        <div class="mb-4">
                            <label for="unit_qty_0" class="block text-sm font-medium text-gray-700">Unit Quantity</label>
                            <input type="number" name="unit_qty[]" id="unit_qty_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                        </div>
                        <div class="mb-4">
                            <label for="price_0" class="block text-sm font-medium text-gray-700">Price</label>
                            <input type="number" name="price[]" id="price_0" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" required>
                        </div>
                    </div>
                </div>

                <button type="button" id="add-variant" class="bg-gray-200 text-gray-700 py-2 px-4 rounded hover:bg-gray-300">Add Another Variant</button>
            </div>

            <!-- Pricing Tab -->
            <div class="tab-pane hidden" id="pricing">
                <div class="mb-4">
                    <label for="cost" class="block text-sm font-medium text-gray-700">Cost</label>
                    <input type="number" name="cost" id="cost" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" value="<?php echo e(old('cost')); ?>" required>
                    <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <div class="mb-4">
                    <label for="sale" class="block text-sm font-medium text-gray-700">Sale Price (Optional)</label>
                    <input type="number" name="sale" id="sale" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" value="<?php echo e(old('sale')); ?>">
                    <?php $__errorArgs = ['sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="mt-2 text-sm text-red-600"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
            </div>
        </div>

        <button type="submit" class="bg-blue-500 text-white py-2 px-4 rounded hover:bg-blue-600 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-opacity-50 mt-6">Create Product</button>
    </form>

    <script>
        document.addEventListener('DOMContentLoaded', function() {
            const tabs = document.querySelectorAll('[data-target]');
            const tabPanes = document.querySelectorAll('.tab-pane');

            tabs.forEach(tab => {
                tab.addEventListener('click', function() {
                    const target = document.querySelector(this.getAttribute('data-target'));

                    // Remove active class from all tabs and hide all tab panes
                    tabs.forEach(t => t.classList.remove('text-blue-500', 'border-blue-500'));
                    tabPanes.forEach(pane => pane.classList.add('hidden'));

                    // Add active class to the clicked tab and show the target tab pane
                    this.classList.add('text-blue-500', 'border-blue-500');
                    target.classList.remove('hidden');
                });
            });

            // Set the initial active tab
            document.querySelector('#general-tab').click();
        });

        document.getElementById('add-variant').addEventListener('click', function() {
            const container = document.getElementById('variants-container');
            const index = container.children.length; // Get current count of variants

            const newVariant = `
                <div class="variant mb-4">
                    <div class="mb-4">
                        <label for="unit_type_${index}" class="block text-sm font-medium text-gray-700">Unit Type</label>
                        <input type="text" name="unit_type[]" id="unit_type_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                    </div>
                    <div class="mb-4">
                        <label for="unit_qty_${index}" class="block text-sm font-medium text-gray-700">Unit Quantity</label>
                        <input type="number" name="unit_qty[]" id="unit_qty_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" required>
                    </div>
                    <div class="mb-4">
                        <label for="price_${index}" class="block text-sm font-medium text-gray-700">Price</label>
                        <input type="number" name="price[]" id="price_${index}" class="mt-1 block w-full border-gray-300 rounded-md shadow-sm focus:border-blue-500 focus:ring focus:ring-blue-500 focus:ring-opacity-50" step="0.01" required>
                    </div>
                </div>
            `;

            container.insertAdjacentHTML('beforeend', newVariant);
        });
    </script>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/products/create.blade.php ENDPATH**/ ?>