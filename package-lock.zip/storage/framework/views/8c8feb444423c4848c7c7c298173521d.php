

<?php $__env->startSection('title', 'Store Inventories'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-4">Store Inventories</h1>

        <!-- Filter and View Options -->
        <div class="mb-4">
            <a href="<?php echo e(route('store_inventories.create')); ?>" class="bg-blue-500 text-white px-4 py-2 rounded-md hover:bg-blue-600">Add New Inventory</a>
        </div>

        <!-- Inventories Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-md">
                <thead>
                    <tr class="bg-gray-100 border-b border-gray-200">
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Store</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Actions</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($inventory->store->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($inventory->product->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($inventory->quantity); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap text-sm font-medium">
                                <a href="<?php echo e(route('store_inventories.show', $inventory->store_id)); ?>" class="text-blue-500 hover:text-blue-600">View</a>
                                <form action="<?php echo e(route('store_inventories.destroy', $inventory->id)); ?>" method="POST" class="inline">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>
                                    <button type="submit" class="text-red-500 hover:text-red-600 ml-2" onclick="return confirm('Are you sure you want to delete this inventory?')">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>

        <!-- Pagination -->
        <div class="mt-4">
            <?php echo e($inventories->links()); ?>

        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/store_inventories/index.blade.php ENDPATH**/ ?>