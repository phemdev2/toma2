<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Settings</title>
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
    <style>
        /* Custom styles for a modern look */
        body {
            background-color: #f3f4f6;
            font-family: 'Arial', sans-serif;
        }

        .card {
            background-color: #ffffff;
            box-shadow: 0 4px 6px rgba(0, 0, 0, 0.1);
            border-radius: 0.5rem;
        }

        .card-header {
            border-bottom: 1px solid #e5e7eb;
            padding: 1.5rem;
        }

        .card-body {
            padding: 1.5rem;
        }

        .btn-primary {
            background-color: #1d4ed8;
            color: #ffffff;
            border: none;
            padding: 0.75rem 1.5rem;
            border-radius: 0.375rem;
            cursor: pointer;
            transition: background-color 0.2s ease-in-out;
        }

        .btn-primary:hover {
            background-color: #2563eb;
        }

        .form-select {
            border: 1px solid #d1d5db;
            border-radius: 0.375rem;
            padding: 0.75rem 1rem;
            width: 100%;
            transition: border-color 0.2s;
        }

        .form-select:focus {
            border-color: #1d4ed8;
            outline: none;
            box-shadow: 0 0 0 0.2rem rgba(29, 78, 216, 0.25);
        }

        @media (max-width: 640px) {
            .container {
                padding: 0 1rem;
            }
        }
    </style>
</head>
<body>
    <div class="min-h-screen flex flex-col">
        <!-- Header -->
        <header class="bg-gray-800 text-white p-4 shadow-md">
            <div class="container mx-auto flex justify-between items-center">
                <h1 class="text-2xl font-semibold">Admin Dashboard</h1>
                <nav class="space-x-4">
                    <a href="#" class="hover:text-gray-300">Dashboard</a>
                    <a href="#" class="hover:text-gray-300">Settings</a>
                    <a href="#" class="hover:text-gray-300">Logout</a>
                </nav>
            </div>
        </header>

        <!-- Main Content -->
        <main class="flex-grow container mx-auto p-6">
            <div class="card">
                <div class="card-header">
                    <h2 class="text-3xl font-semibold text-gray-800">Admin Settings</h2>
                </div>

                <!-- Success Message -->
                <?php if(session('success')): ?>
                    <div class="bg-green-600 text-white p-4 rounded-lg mb-6">
                        <?php echo e(session('success')); ?>

                    </div>
                <?php endif; ?>

                <!-- Error Messages -->
                <?php if($errors->any()): ?>
                    <div class="bg-red-600 text-white p-4 rounded-lg mb-6">
                        <ul class="list-disc pl-5">
                            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li><?php echo e($error); ?></li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                    </div>
                <?php endif; ?>

                <!-- Settings Form -->
                <form action="<?php echo e(route('admin.settings.update')); ?>" method="POST" class="card-body space-y-6">
                    <?php echo csrf_field(); ?>
                    <div class="space-y-4">
                        <div>
                            <label for="allow_overselling" class="block text-sm font-medium text-gray-700">Allow Overselling</label>
                            <select id="allow_overselling" name="allow_overselling" class="form-select mt-1">
                                <option value="1" <?php echo e($allowOverselling === 'true' ? 'selected' : ''); ?>>Yes</option>
                                <option value="0" <?php echo e($allowOverselling === 'false' ? 'selected' : ''); ?>>No</option>
                            </select>
                        </div>
                    </div>
                    <button type="submit" class="btn-primary w-full">Save Settings</button>
                </form>
            </div>
        </main>

        <!-- Footer -->
        <footer class="bg-gray-800 text-white p-4 mt-auto">
            <div class="container mx-auto text-center">
                <p class="text-sm">&copy; 2024 Admin Dashboard. All rights reserved.</p>
            </div>
        </footer>
    </div>
</body>
</html><?php /**PATH C:\Users\new\toma2\resources\views/admin/settings/index.blade.php ENDPATH**/ ?>