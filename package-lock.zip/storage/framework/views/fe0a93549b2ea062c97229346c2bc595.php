<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shopping Cart</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f9f9f9;
        }
        .cart {
            width: 40%;
            max-width: 800px;
            margin: 20px auto;
            padding: 20px;
            background-color: #fff;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .cart h2 {
            font-size: 1.5em;
            margin-bottom: 20px;
        }
        .cart table {
            width: 100%;
            border-collapse: collapse;
        }
        .cart table, .cart th, .cart td {
            border: 1px solid #ddd;
        }
        .cart th, .cart td {
            padding: 12px;
            text-align: left;
        }
        .cart th {
            background-color: #f4f4f4;
        }
        .cart .total {
            font-weight: bold;
            margin-top: 20px;
            font-size: 1.2em;
        }
        .delete-icon {
            cursor: pointer;
            color: red;
            font-size: 1.2em;
            text-align: center;
            user-select: none;
        }
        .checkout-buttons button {
            display: block;
            width: 100%;
            padding: 10px;
            font-size: 1em;
            color: #fff;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            margin-bottom: 10px;
        }
        .checkout-buttons .clear-cart {
            background-color: #17a2b8;
        }
        .checkout-buttons .checkout {
            background-color: #28a745;
        }
        .checkout-buttons button:hover {
            opacity: 0.9;
        }
        @media (max-width: 600px) {
            .cart table, .cart th, .cart td {
                font-size: 0.9em;
            }
        }
    </style>
</head>
<body>
    <div class="cart container">
        <h2>Shopping Cart</h2>
        <?php if(session('success')): ?>
            <div class="alert alert-success">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <?php if(count($cart) > 0): ?>
            <table>
                <thead>
                    <tr>
                        <th>Product</th>
                        <th>Price</th>
                        <th>Quantity</th>
                        <th>Total</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemName => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item['name']); ?></td>
                            <td>$<?php echo e(number_format($item['price'], 2)); ?></td>
                            <td><?php echo e($item['quantity']); ?></td>
                            <td>$<?php echo e(number_format($item['price'] * $item['quantity'], 2)); ?></td>
                            <td>
                                <form action="<?php echo e(route('cart.remove')); ?>" method="POST">
                                    <?php echo csrf_field(); ?>
                                    <input type="hidden" name="item_name" value="<?php echo e($itemName); ?>">
                                    <button type="submit" class="btn btn-danger btn-sm">Remove</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
            <p class="total">Total: $<?php echo e(number_format($total, 2)); ?></p>
            <div class="checkout-buttons">
                <form action="<?php echo e(route('cart.clear')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-info clear-cart">Clear Cart</button>
                </form>
                <form action="<?php echo e(route('cart.checkout')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <button type="submit" class="btn btn-success checkout">Checkout</button>
                </form>
            </div>
        <?php else: ?>
            <p>Your cart is empty!</p>
        <?php endif; ?>
    </div>
</body>
</html>
<?php /**PATH C:\Users\new\toma2\resources\views/cart/index.blade.php ENDPATH**/ ?>