

<?php $__env->startSection('title', 'Edit Product'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto p-4">
        <h1 class="text-2xl font-bold mb-6">Edit Product</h1>

        <?php if(session('success')): ?>
            <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4">
                <?php echo e(session('success')); ?>

            </div>
        <?php endif; ?>

        <form action="<?php echo e(route('products.update', $product->id)); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field('PUT'); ?>

            <!-- Tabs Navigation -->
            <ul class="flex border-b mb-4">
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-blue-600 border-b-2 border-blue-600 cursor-pointer" id="general-tab" data-toggle="tab" href="#general">General Info</a>
                </li>
                <li class="mr-1">
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-600 cursor-pointer" id="pricing-tab" data-toggle="tab" href="#pricing">Pricing</a>
                </li>
                <li>
                    <a class="inline-block py-2 px-4 text-gray-600 hover:text-blue-600 cursor-pointer" id="variants-tab" data-toggle="tab" href="#variants">Variants</a>
                </li>
            </ul>

            <!-- Tab Content -->
            <div class="tab-content">
                <!-- General Info Tab -->
                <div id="general" class="tab-pane hidden">
                    <div class="mb-4">
                        <label for="name" class="block text-gray-700">Product Name</label>
                        <input type="text" name="name" id="name" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('name', $product->name)); ?>" required>
                        <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 mt-1 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label for="barcode" class="block text-gray-700">Barcode</label>
                        <input type="text" name="barcode" id="barcode" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('barcode', $product->barcode)); ?>" required>
                        <?php $__errorArgs = ['barcode'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 mt-1 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label for="description" class="block text-gray-700">Description</label>
                        <textarea name="description" id="description" class="form-textarea mt-1 block w-full border-gray-300 rounded-md shadow-sm"><?php echo e(old('description', $product->description)); ?></textarea>
                        <?php $__errorArgs = ['description'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 mt-1 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Pricing Tab -->
                <div id="pricing" class="tab-pane hidden">
                    <div class="mb-4">
                        <label for="cost" class="block text-gray-700">Cost</label>
                        <input type="number" name="cost" id="cost" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('cost', $product->cost)); ?>" step="0.01" required>
                        <?php $__errorArgs = ['cost'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 mt-1 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>

                    <div class="mb-4">
                        <label for="sale" class="block text-gray-700">Sale Price (Optional)</label>
                        <input type="number" name="sale" id="sale" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('sale', $product->sale)); ?>" step="0.01">
                        <?php $__errorArgs = ['sale'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <div class="text-red-500 mt-1 text-sm"><?php echo e($message); ?></div>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>

                <!-- Variants Tab -->
                <div id="variants" class="tab-pane hidden">
                    <div class="overflow-x-auto">
                        <table class="min-w-full bg-white border border-gray-300" id="variants-table">
                            <thead>
                                <tr class="border-b">
                                    <th class="px-4 py-2 text-left">Unit Type</th>
                                    <th class="px-4 py-2 text-left">Unit Quantity</th>
                                    <th class="px-4 py-2 text-left">Price</th>
                                    <th class="px-4 py-2 text-left">Action</th>
                                </tr>
                            </thead>
                            <tbody id="variants-container">
                                <?php $__currentLoopData = $product->variants; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $variant): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr id="variant_<?php echo e($index); ?>" class="border-b">
                                        <td class="px-4 py-2">
                                            <input type="text" name="unit_type[]" id="unit_type_<?php echo e($index); ?>" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('unit_type.' . $index, $variant->unit_type)); ?>" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <input type="number" name="unit_qty[]" id="unit_qty_<?php echo e($index); ?>" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('unit_qty.' . $index, $variant->unit_qty)); ?>" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <input type="number" name="price[]" id="price_<?php echo e($index); ?>" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" value="<?php echo e(old('price.' . $index, $variant->price)); ?>" step="0.01" required>
                                        </td>
                                        <td class="px-4 py-2">
                                            <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 delete-variant" data-index="<?php echo e($index); ?>">Delete</button>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                        <button type="button" id="add-variant" class="mt-3 px-4 py-2 bg-gray-200 text-gray-800 rounded hover:bg-gray-300">Add Another Variant</button>
                    </div>
                </div>
            </div>

            <button type="submit" class="mt-4 px-4 py-2 bg-blue-500 text-white rounded hover:bg-blue-600">Update Product</button>
        </form>

        <script>
            document.addEventListener('DOMContentLoaded', function() {
                const tabs = document.querySelectorAll('[data-toggle="tab"]');
                const tabPanes = document.querySelectorAll('.tab-pane');

                tabs.forEach(tab => {
                    tab.addEventListener('click', function() {
                        // Remove active class from all tabs and hide all tab panes
                        tabs.forEach(t => t.classList.remove('text-blue-600', 'border-blue-600'));
                        tabPanes.forEach(pane => pane.classList.add('hidden'));

                        // Add active class to the clicked tab and show the corresponding tab pane
                        tab.classList.add('text-blue-600', 'border-blue-600');
                        const targetPane = document.querySelector(tab.getAttribute('href'));
                        targetPane.classList.remove('hidden');
                    });
                });

                // Set the default tab to active
                document.getElementById('general-tab').click();
            });

            document.getElementById('add-variant').addEventListener('click', function() {
                const container = document.getElementById('variants-container');
                const index = container.children.length;

                const newVariantRow = `
                    <tr id="variant_${index}" class="border-b">
                        <td class="px-4 py-2">
                            <input type="text" name="unit_type[]" id="unit_type_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        </td>
                        <td class="px-4 py-2">
                            <input type="number" name="unit_qty[]" id="unit_qty_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" required>
                        </td>
                        <td class="px-4 py-2">
                            <input type="number" name="price[]" id="price_${index}" class="form-input mt-1 block w-full border-gray-300 rounded-md shadow-sm" step="0.01" required>
                        </td>
                        <td class="px-4 py-2">
                            <button type="button" class="bg-red-500 text-white px-3 py-1 rounded hover:bg-red-600 delete-variant" data-index="${index}">Delete</button>
                        </td>
                    </tr>
                `;

                container.insertAdjacentHTML('beforeend', newVariantRow);
            });

            document.addEventListener('click', function(e) {
                if (e.target && e.target.classList.contains('delete-variant')) {
                    const index = e.target.getAttribute('data-index');
                    const variantElement = document.getElementById(`variant_${index}`);
                    if (variantElement) {
                        variantElement.remove();
                    }
                }
            });
        </script>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/products/edit.blade.php ENDPATH**/ ?>