

<?php $__env->startSection('title', 'Store Inventory Details'); ?>

<?php $__env->startSection('content'); ?>
    <div class="container mx-auto px-4 py-6">
        <h1 class="text-3xl font-semibold mb-4"><?php echo e($store->name); ?> - Inventory Details</h1>

        <a href="<?php echo e(route('store_inventories.index')); ?>" class="bg-gray-500 text-white px-4 py-2 rounded-md hover:bg-gray-600 mb-4 inline-block">Back to Inventory List</a>

        <!-- Inventories Table -->
        <div class="overflow-x-auto">
            <table class="min-w-full bg-white border border-gray-200 rounded-lg shadow-md">
                <thead class="bg-gray-100 border-b border-gray-200">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Product</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Quantity</th>
                    </tr>
                </thead>
                <tbody class="bg-white divide-y divide-gray-200">
                    <?php $__currentLoopData = $inventories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $inventory): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($inventory->product->name); ?></td>
                            <td class="px-6 py-4 whitespace-nowrap"><?php echo e($inventory->quantity); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\new\toma2\resources\views/store_inventories/show.blade.php ENDPATH**/ ?>